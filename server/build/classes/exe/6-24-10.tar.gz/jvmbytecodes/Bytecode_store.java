package exe.jvmbytecodes;
import java.io.IOException;
import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;
/*
 * Recognizes all byte codes that contain store
 * only iload implemented
 */
public class Bytecode_store extends Bytecode_
{

	Bytecode_store(String str) 
	{
		parse(str);
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		//Store
		next = lineNumber+1;
		
		//istore
		if(opcode.contains("i"))
		{
			System.out.println("Enter istore");

			int index = getLocalVariableTable(arguments.get(0), gbc);
			Integer x;
			x = (Integer) _stack.pop();
			gbc.classes[0].methods.get(1).localVariableTable[index][2] = String.valueOf(x);
			stack.set("",currentStackHeight++);
			localVariableArray.set(String.valueOf(x), index, "#FFCC11");
			show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);	
			localVariableArray.setColor(index, "#999999");
		}

		if(underscore.compareTo("_") == 0)
			return next;
		else
			next += 1;
			return next;
	}
}
