package exe.jvmbytecodes;
import java.io.IOException;
import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;
/*
 * Recognizes all byte codes that contain mul
 * Working on 18/6/10
 */
class Bytecode_mul extends Bytecode_ {
	
	/*
	 * Constructor that parses the current bytecode 
	 */
	Bytecode_mul(String str) {
		parse(str);
	}

	/*
	 * executes the current line
	 * @return line number
	 */
	public int execute(GenerateBytecodes gbc) throws IOException {
		
		next = lineNumber+1;
	
		//pop and grab objects on the stack
		Object x, y;
		x = _stack.pop();
		stack.set("",currentStackHeight++);

		y = _stack.pop();
		stack.set("",currentStackHeight++);

		//determine if the opcode is int long float or double
		if(opcode.contains("i")) //the opcode is imul
		{
			System.out.println("Enter imul");
			_stack.push((Integer) x * (Integer) y);
			stack.set((Integer) x * (Integer) y,--currentStackHeight);
			show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
		}
		else if(opcode.contains("l")) //the opcode lmul
		{
			_stack.push((Long) x * (Long) y);
			stack.set((Long) x * (Long) y,--currentStackHeight);
			show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
		}
		else if(opcode.contains("f")) //the opcode fmul
		{
			_stack.push((Float) x * (Float) y);
			stack.set((Float) x * (Float) y,--currentStackHeight);
			show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
		}

		//dmul
		else if(opcode.contains("d"))
		{
			_stack.push((Double) x * (Double) y);
			stack.set((Double) x * (Double) y,--currentStackHeight);
			show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
		}
		else
		{
			System.err.println("Unrecognized opcode");
		}

		return next;
	}
}
