package exe.jvmbytecodes;
import java.io.IOException;
import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;
/*
 * Recognizes all byte codes that contain const
 * only i implemented
 */
public class Bytecode_load extends Bytecode_
{

	Bytecode_load(String str) 
	{
		//System.out.println("Enter Bytecode_load constructor");
		parse(str);
		//System.out.println("Complete Bytecode_parse");
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		next = lineNumber+1;
		//Load
		System.out.println("Next starts as: " + next);
		//iload
		if(opcode.contains("i"))
		{
			System.out.println("Enter iload");

			int index = getLocalVariableTable(arguments.get(0), gbc);

			_stack.push(Integer.parseInt(gbc.classes[0].methods.get(1).localVariableTable[index][2]));
			stack.set((String) gbc.classes[0].methods.get(1).localVariableTable[index][2], --currentStackHeight, "#FFCC11");

			show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
			stack.setColor(currentStackHeight, "#999999");
		}

		if(underscore.compareTo("_") == 0)
		{
			;
		}
		else
		{
			next += 1;
		}
		return next;
	}
/*
for (int r=0; r < gbc.classes[0].methods.get(1).localVariableTable.length; r++) 
{
    for (int c=0; c < gbc.classes[0].methods.get(1).localVariableTable[r].length; c++) 
	{
		System.out.println(gbc.classes[0].methods.get(1).localVariableTable[r][c]);
	}
}
*/
}
