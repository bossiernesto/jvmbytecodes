package exe.jvmbytecodes;
import java.io.IOException;

/*
 * Recognizes all byte codes that contain store
 * only iload implemented
 */
public class Bytecode_store extends Bytecode_
{

	Bytecode_store(String str) 
	{
		//System.out.println("Enter Bytecode_store constructor");
		parse(str);
		//System.out.println("Complete Bytecode_parse");
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		//Store
		next = lineNumber+1;
		show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);	
		//istore
		if(opcode.contains("i"))
		{
			System.out.println("Enter istore");

			int index = getLocalVariableTable(arguments.get(0), gbc);
			Integer x;
			x = (Integer) _stack.pop();
			gbc.classes[0].methods.get(1).localVariableTable[index][2] = String.valueOf(x);
			stack.set("",currentStackHeight++);
			localVariableArray.set(String.valueOf(x), index);
			show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);	
		}
		//System.out.println("Finish istore");

		if(underscore.compareTo("_") == 0)
			return next;
		else
			next += 1;
			System.out.println(next);
			return next;
	}
}
