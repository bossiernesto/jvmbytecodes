package my_package;

/** multi-line
 * comment 
 */

import static java.lang.Math.max;

class Test {

    // comment
    private int n;      // comment
    protected char c;
    
    Test() {
	d = 4.0;
	s = "knock ";
	s = new String(" knock ");
	s = s + s;
    }

    public boolean b;
    String s;

    private int m(int x) {
	int sum = 0;
	x = max( 0, x );
	while (x>0) {
	    sum += x--;
	}
	return sum;
    }
    
    double d;

    public static void main(String[] args) {
	System.out.println( new Test().m(5) );
    }

    String[][] a;
}
