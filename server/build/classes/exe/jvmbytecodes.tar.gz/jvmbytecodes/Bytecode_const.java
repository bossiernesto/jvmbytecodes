package exe.jvmbytecodes;
import java.io.IOException;

/*
 * Recognizes all byte codes that contain const
 */
public class Bytecode_const extends Bytecode_
{

	Bytecode_const(String str) 
	{
		System.out.println("Enter Bytecode_const constructor");
		parse(str);
		//System.out.println("Complete Bytecode_parse");
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		//Const
		//total: 13
		next = lineNumber+1;
		//iconst -1, 0, 1, 2, 3, 4, 5
		if(opcode.contains("i"))
		{
			if(arguments.get(0).compareTo("m1") == 0)
			{
				_stack.push( (int) -1);
				stack.set((int) -1, --currentStackHeight);
				show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
				System.out.println(_stack.peek() + " " + _stack.peek().getClass());
			}
			
			else
			{
				
				System.out.println("Enter iconst_");
				//System.out.println(arguments.get(0));
				//System.out.println(currentStackHeight);
				_stack.push(Integer.parseInt(arguments.get(0)));
				stack.set(arguments.get(0), --currentStackHeight);
				System.out.println("Cory");
				show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);	
				System.out.println(_stack.peek() + " " + _stack.peek().getClass());
			}
		}

		//lconst 0, 1
		else if(opcode.contains("l"))
		{
			_stack.push(Long.parseLong(arguments.get(0)));
			stack.set(arguments.get(0), --currentStackHeight);
			show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);		
			//System.out.println(_stack.peek() + " " + _stack.peek().getClass());
		}

		//fconst_ 0, 1, 2
		else if(opcode.contains("f"))
		{
			_stack.push(Float.parseFloat(arguments.get(0)));
			stack.set(arguments.get(0), --currentStackHeight);
			show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
			//System.out.println(_stack.peek() + " " + _stack.peek().getClass());
		}

		//dconst 0, 1
		else if(opcode.contains("d"))
		{
			_stack.push(Double.parseDouble(arguments.get(0)));
			stack.set(arguments.get(0), --currentStackHeight);
			show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
			//System.out.println(_stack.peek() + " " + _stack.peek().getClass());
		}

		else
		{
			System.out.println("Unrecognized opcode");
		}
		
		return next;
	}
}
