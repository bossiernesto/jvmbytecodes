package exe.jvmbytecodes;
import java.io.IOException;

/*
 * Recognizes all byte codes that contain goto
 * only goto
 */
public class Bytecode_goto extends Bytecode_
{

	Bytecode_goto(String str) 
	{
		//System.out.println("Enter Bytecode_if constructor");
		parse(str);
		//System.out.println("Complete Bytecode_parse");
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		//Goto
		next = Integer.parseInt(arguments.get(0));

		show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), stack, heap, runTimeStack, localVariableArray);
		System.out.println("Enter goto");
		System.out.println("Goto line " + next);
		return next;
	}
}
