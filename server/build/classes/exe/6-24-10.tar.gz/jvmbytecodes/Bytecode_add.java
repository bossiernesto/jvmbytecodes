package exe.jvmbytecodes;

import java.io.IOException;

class Bytecode_add extends Bytecode_ {
	
	
	Bytecode_add(String str) {
		System.out.println("Enter Bytecode_add constructor");
		parse(str);
		System.out.println("Complete Bytecode_parse");
	}

	public int execute(GenerateBytecodes gbc) throws IOException {
		System.out.println("Enter Bytecode_add execute");
		//Add
		//total: 4
		//I have tested each path in this block 15/6/10
		if(opcode.contains("add"))
		{
		Object x, y;
		x = _stack.pop();
		y = _stack.pop();
		//iadd
		if(opcode.contains("i"))
		{
		_stack.push((Integer) x + (Integer) y);
		System.out.println(_stack.peek() + " " + _stack.peek().getClass());
		}
		//ladd
		else if(opcode.contains("l"))
		{
		_stack.push((Long) x + (Long) y);
		System.out.println(_stack.peek() + " " + _stack.peek().getClass());
		}
		//fadd
		else if(opcode.contains("f"))
		{
		_stack.push((Float) x + (Float) y);
		System.out.println(_stack.peek() + " " + _stack.peek().getClass());
		}
		//dadd
		else if(opcode.contains("d"))
		{
		_stack.push((Double) x + (Double) y);
		System.out.println(_stack.peek() + " " + _stack.peek().getClass());
		}
		else
		{
		System.out.println("Unrecognized opcode");
		}
		show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
		}
		return 1;
	}
}
