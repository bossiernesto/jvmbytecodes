package exe.jvmbytecodes;
import java.io.IOException;

import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;



/*
 * Recognizes all byte codes that contain if
 * only if_cmpgt
 */
public class Bytecode_if extends Bytecode_
{
    int counter = 0;

	Bytecode_if(String str) 
	{
		parse(str);
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		next = lineNumber + 1;
		next = next + 2;
		//If
		Integer x, y;
		Random rand = new Random();
		int random = rand.nextInt(2);
		//if_cmpgt

		if(arguments.get(0).contains("icmp"))
		{
			System.out.println("Enter if_icmp");	
			if(arguments.get(0).contains("icmpgt"))
			{				
				System.out.println("Enter if_icmpgt");		
				x = (Integer) _stack.pop();

				System.out.println(_stack);
				y = (Integer) _stack.pop();

				if (counter == 0) {
				    createQuestion1(x, y, gbc);
				    counter++;
				}else
				    createQuestion2(x, y, gbc);

				/*
				if(random == 1)
				{
					createQuestion1(x, y, gbc);
				}				}
				else
				{
					createQuestion2(x, y, gbc);
				}
				*/
				questionID++;
				if( x > y-1)
				    {  /* no jump */ }
				else
				    next = Integer.parseInt(arguments.get(1));
				stack.set("",currentStackHeight++);
				stack.set("",currentStackHeight++);
			}		
		}
		return next;
	}

	void createQuestion1(int x, int y, GenerateBytecodes gbc) throws IOException
	{
		XMLtfQuestion question = new XMLtfQuestion(show, questionID + "");
		question.setQuestionText("The bytecode will jump to line number " + arguments.get(1) + ".");
		question.setAnswer(x<=y);
		stack.setColor(currentStackHeight,"#CD0000");
		stack.setColor(currentStackHeight+1,"#CD0000");
		show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), question, runTimeStack , stack, heap, localVariableArray);
		stack.setColor(currentStackHeight,"#999999");
		stack.setColor(currentStackHeight+1,"#999999");
	}

	void createQuestion2(int x, int y, GenerateBytecodes gbc) throws IOException
	{
		XMLmcQuestion question = new XMLmcQuestion(show, questionID + "");
		question.setQuestionText("What line number will the program jump to next?");
		question.addChoice(next + "");
		question.addChoice(arguments.get(1));
		question.addChoice(lineNumber + "");
			if(x > y)
				question.setAnswer(1);
			else
				question.setAnswer(2);
		stack.setColor(currentStackHeight,"#CD0000");
		stack.setColor(currentStackHeight+1,"#CD0000");
		show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), question, runTimeStack , stack, heap, localVariableArray);
		stack.setColor(currentStackHeight,"#999999");
		stack.setColor(currentStackHeight+1,"#999999");
	}
/*
	void createQuestion3(GenerateBytecodes gbc) throws IOException
	{
		XMLmcQuestion question = new XMLmcQuestion(show, questionID + "");
		question.setQuestionText("What java code does " + opcode + underscore + arguments.get(0) + " imply?");
		question.addChoice("if(value 1 = value 2)");
		question.addChoice("if(value 1 <= value 2");
		question.addChoice("if(value 1 < value 2");
		question.addChoice("if(value 1 > value 2");
		question.addChoice("if(value 1 >= value 2");

		question.setAnswer(3);
		show.writeSnap(TITLE, doc_uri(lineNumber, gbc), make_uri(lineNumber, pseudo.RED, gbc), question, runTimeStack , stack, heap, localVariableArray);
	}*/

}
