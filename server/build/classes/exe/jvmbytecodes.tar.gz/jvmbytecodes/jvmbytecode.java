/* 
   @author William Clements
   @author Caitlyn Pickens
   @author Cory Sheeley
   

*/

package exe.jvmbytecodes;

import exe.*;
import java.io.*;
import java.lang.*;
import java.util.*;

public class jvmbytecode{
    public static void main(String args[]) throws IOException {
	// Send the XML file name from the server to the parser.
	Hashtable hash = XMLParameterParser.parseToHash(args[2]);

	String[] params = new String[2];

	params[0] = args[0] + ".sho";
	params[1] = (String)hash.get("Enter the size of the array :");

	BytecodeViewer.main(params);
    }
}
