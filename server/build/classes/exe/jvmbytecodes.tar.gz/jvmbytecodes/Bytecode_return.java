package exe.jvmbytecodes;
import java.io.IOException;

/*
 * Recognizes all byte codes that contain goto
 * only goto
 */
public class Bytecode_return extends Bytecode_
{

	Bytecode_return(String str) 
	{
		//System.out.println("Enter Bytecode_if constructor");
		parse(str);
		//System.out.println("Complete Bytecode_parse");
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		//return
		next = -1;

		show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack, heap);
		System.out.println("Enter goto");
		System.out.println("Goto line " + next);
		return next;
	}
}
