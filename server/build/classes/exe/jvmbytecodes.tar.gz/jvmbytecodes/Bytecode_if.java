package exe.jvmbytecodes;
import java.io.IOException;

/*
 * Recognizes all byte codes that contain if
 * only if_cmpgt
 */
public class Bytecode_if extends Bytecode_
{

	Bytecode_if(String str) 
	{
		//System.out.println("Enter Bytecode_if constructor");
		parse(str);
		//System.out.println("Complete Bytecode_parse");
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		next = lineNumber + 1;
		next = next + 2;
		//If
		//total: 13
		Integer x, y;

		//if_cmpgt
		if(arguments.get(0).contains("icmp"))
		{
			System.out.println("Enter if_icmp");	
			if(arguments.get(0).contains("icmpgt"))
			{				
				System.out.println("Enter if_icmpgt");
				System.out.println(_stack);			
				x = (Integer) _stack.pop();
				System.out.println(_stack);
				stack.set("",currentStackHeight++);
				//show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
				System.out.println(_stack);
				y = (Integer) _stack.pop();
				stack.set("",currentStackHeight++);
				show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
				System.out.println(x + ">" + y + "?");
				System.out.println(_stack);
				if( x > y)
					;
				else
					next = Integer.parseInt(arguments.get(1));
				
			}		
		}
		return next;
	}
}
