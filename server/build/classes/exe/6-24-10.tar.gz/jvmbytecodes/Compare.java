package exe.jvmbytecodes;
import java.io.*;
import java.util.*;

public class Compare implements Comparator
{
	public int compare(Object obj1, Object obj2) {
		String[] x, y;
		x = (String[]) obj1;
		y = (String[]) obj2;
		if(Integer.parseInt(x[0]) < Integer.parseInt(y[0]))
			return -1;
		else
			return 1;
	}
}
