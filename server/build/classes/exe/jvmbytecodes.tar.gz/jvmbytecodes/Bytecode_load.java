package exe.jvmbytecodes;
import java.io.IOException;

/*
 * Recognizes all byte codes that contain const
 * only i implemented
 */
public class Bytecode_load extends Bytecode_
{

	Bytecode_load(String str) 
	{
		//System.out.println("Enter Bytecode_load constructor");
		parse(str);
		//System.out.println("Complete Bytecode_parse");
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		next = lineNumber+1;
		//Load
		System.out.println("Next starts as: " + next);
		//iload
		if(opcode.contains("i"))
		{
			System.out.println("Enter iload");

			int index = getLocalVariableTable(arguments.get(0), gbc);
/*
for (int r=0; r < gbc.classes[0].methods.get(1).localVariableTable.length; r++) 
{
    for (int c=0; c < gbc.classes[0].methods.get(1).localVariableTable[r].length; c++) 
	{
		System.out.println(gbc.classes[0].methods.get(1).localVariableTable[r][c]);
	}
}
*/
			_stack.push(Integer.parseInt(gbc.classes[0].methods.get(1).localVariableTable[index][2]));
			stack.set((String) gbc.classes[0].methods.get(1).localVariableTable[index][2], --currentStackHeight);
			System.out.println("Arguments: " + arguments);
			show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
			System.out.println(_stack);
		}

		if(underscore.compareTo("_") == 0)
		{
			System.out.println("Underscore");
			System.out.println("Next line: " + next);
		}
		else
		{
			System.out.println("No underscore");
			next += 1;
			System.out.println("Next line: " + next);
		}
		return next;
	}
}
