package exe.jvmbytecodes;
import java.io.IOException;
import java.lang.InterruptedException;
import java.io.File;
import java.io.FilenameFilter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;


import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;



 class BytecodeViewer { 

	static final String TITLE = null;   
	static final String FILE = "exe/jvmbytecodes/template.xml";
	static final String CLASSFILE = "exe/jvmbytecodes/classTemplate.xml";

	static PseudoCodeDisplay pseudo;
   	static PseudoCodeDisplay realCode;
    static ShowFile show;
	static int numberOfLinesInJavaFile=1;
	static int stackSize=0;
	static int heapSize=0;
	static int currentStackHeight;
	static int currentMethod = 1;	
	static GAIGSarray stack;
	static GAIGSarray localVariableArray;
	static GAIGSstack runTimeStack;
	static GAIGSstack heap;
	static Stack _stack = new Stack();
	static ArrayList _heap;
	static int currentClass;
	int questionID;
	static MakeURI muri = new MakeURI();
    
    public static void main(String args[])  throws IOException {
    	System.out.println("BytecodeViewer.java args[0]: "+args[0]+" args[1]: "+args[1]+" args[2]: "+args[2]);
		BytecodeViewer bcv = new BytecodeViewer();
		bcv.runViewer(args);
   
    }
	
	
	public void runViewer(String a[]) throws IOException
	{
		show = new ShowFile(a[0],5); //first argument is the script foo.sho
		
    	//generate the bytecodes
		//String[] temp = {"../../src/exe/jvmbytecode/Test","Factorial4.java"};
		String[] temp = { a[1] , a[2] } ;
		GenerateBytecodes gbc = new GenerateBytecodes();
		gbc.run(temp);
		
		//create visual stack and heap using the predetermined sizes
		stackSize = gbc.classes[0].methods.get(1).stackSize;
		currentStackHeight = gbc.classes[0].methods.get(1).stackSize;
		stack = new GAIGSarray(stackSize, false, "Operand Stack", "#999999", 0.5,0.1,0.9, 0.5, 0.1);
		heap = new GAIGSstack("Heap", "#999999", 0.01,0.5, 0.3, 0.9, 0.15);
		runTimeStack = new GAIGSstack("Run Time Stack", "#999999", 0.01,0.1,0.3, 0.5, 0.15);

		//new xml file		
		currentClass=0; 
		GenerateXML.generateXMLfile(gbc);	
		GenerateXML.generateJavaXMLFile(gbc,a[1],a[2]);
		
        	try {
		    pseudo = new PseudoCodeDisplay(FILE);
		    realCode = new PseudoCodeDisplay(CLASSFILE);
		} 
		catch (JDOMException e) {
		    e.printStackTrace();
		}

		firstMethodCall(gbc);
		//begin interpreter
		Interpreter interp = new Interpreter();
		interp.interpret(gbc.classes[0].methods.get(1).bytecodes, gbc);
		
		runTimeStack.pop();
		show.writeSnap(TITLE, muri.doc_uri(-1, gbc), muri.make_uri(-1, pseudo.RED, gbc), heap, runTimeStack);
		show.close();
	}

	void firstMethodCall(GenerateBytecodes gbc) throws IOException
	{
		//display first method call
		setStackToInitialValues(gbc);
		String mainColor = getRandomColor();
		runTimeStack.push(gbc.classes[0].methods.get(1).name, mainColor);
		localVariableArray = new GAIGSarray(gbc.classes[0].methods.get(1).localVariableTable.length, false, "Local Variables", "#999999", 0.5,0.5,0.9, 0.9, 0.1);		
		for(int i = 0; i < gbc.classes[0].methods.get(1).localVariableTable.length; i++)
		{
			String[][] array = sortLocalVariableArray(gbc);
			localVariableArray.set( "", i);
			localVariableArray.setRowLabel(array[i][1] + " | " + array[i][0], i);
		}
		show.writeSnap(TITLE, muri.doc_uri(-1, gbc), muri.make_uri(-1, pseudo.RED, gbc), heap, runTimeStack);
		show.writeSnap(TITLE, muri.doc_uri(-1, gbc), muri.make_uri(-1, pseudo.RED, gbc), heap, runTimeStack, stack, localVariableArray);
	}

	String[][] sortLocalVariableArray(GenerateBytecodes gbc)
	{
		String[][] array = gbc.classes[0].methods.get(1).localVariableTable;
		Arrays.sort(array, new Compare());
		return array;
	}

	void setStackToInitialValues(GenerateBytecodes gbc) throws IOException
	{
		questionID = 0;
		for(int i = 0; i < stackSize; i++)
			stack.set("", i);
		show.writeSnap(TITLE, muri.doc_uri(-1, gbc), muri.make_uri(-1, pseudo.RED, gbc), heap, runTimeStack);
	}

  
		
   

 	static String getRandomColor() {
 		String returnStr="#";
 		int temp=0;
 		for(int i=0; i<6; i++) {
 			Random rand = new Random();
 			temp = rand.nextInt(7);
 			if (temp == 10)
 				returnStr += "a";
 			else if (temp == 11)
 				returnStr += "b";
 			else if (temp == 12)
 				returnStr += "c";
 			else if (temp == 13)
 				returnStr += "d";
 			else if (temp == 14)
 				returnStr += "e";
 			else if (temp == 15)
 				returnStr += "f";
 			else
 				returnStr += (Integer.toString(temp));
 		}
 		return (returnStr);
 	}


}
 

