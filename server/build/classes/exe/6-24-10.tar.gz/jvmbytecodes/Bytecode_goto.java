package exe.jvmbytecodes;
import java.io.IOException;
import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;
/*
 * Recognizes all byte codes that contain goto
 * only goto
 */
public class Bytecode_goto extends Bytecode_
{

	Bytecode_goto(String str) 
	{
		parse(str);
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		//Goto
		next = Integer.parseInt(arguments.get(0));
		show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), stack, heap, runTimeStack, localVariableArray);
		return next;
	}
}
