package exe.jvmbytecodes;
import java.io.IOException;
import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;
/*
 * Recognizes all byte codes that contain const
 */
public class Bytecode_const extends Bytecode_
{

	Bytecode_const(String str) 
	{
		parse(str);
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		//Const
		//total: 13
		next = lineNumber+1;
		//iconst -1, 0, 1, 2, 3, 4, 5
		if(opcode.contains("i"))
		{
			if(arguments.get(0).compareTo("m1") == 0)
			{
				_stack.push( (int) -1);
				stack.set((int) -1, --currentStackHeight, "#FFCC11");
				show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
				stack.setColor(currentStackHeight, "#999999");
			}
			
			else
			{
				_stack.push(Integer.parseInt(arguments.get(0)));
				stack.set(arguments.get(0), --currentStackHeight, "#FFCC11");
				show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);	
				stack.setColor(currentStackHeight, "#999999");
			}
		}

		//lconst 0, 1
		else if(opcode.contains("l"))
		{
			_stack.push(Long.parseLong(arguments.get(0)));
			stack.set(arguments.get(0), --currentStackHeight);
			show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);		
		}

		//fconst_ 0, 1, 2
		else if(opcode.contains("f"))
		{
			_stack.push(Float.parseFloat(arguments.get(0)));
			stack.set(arguments.get(0), --currentStackHeight);
			show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
		}

		//dconst 0, 1
		else if(opcode.contains("d"))
		{
			_stack.push(Double.parseDouble(arguments.get(0)));
			stack.set(arguments.get(0), --currentStackHeight);
			show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);
		}

		else
		{
			System.out.println("Unrecognized opcode");
		}
		
		return next;
	}
}
