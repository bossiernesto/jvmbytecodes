package exe.jvmbytecodes;
import java.io.IOException;
import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;
/*
 * Recognizes all byte codes that contain goto
 * only goto
 */
public class Bytecode_return extends Bytecode_
{

	Bytecode_return(String str) 
	{
		//System.out.println("Enter Bytecode_if constructor");
		parse(str);
		//System.out.println("Complete Bytecode_parse");
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		//return
		next = -1;

		show.writeSnap(TITLE, muri.doc_uri(lineNumber, gbc), muri.make_uri(lineNumber, pseudo.RED, gbc), runTimeStack, heap);
		System.out.println("Enter goto");
		System.out.println("Goto line " + next);
		return next;
	}
}
