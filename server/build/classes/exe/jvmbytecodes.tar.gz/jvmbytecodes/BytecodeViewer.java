package exe.jvmbytecodes;
import java.io.IOException;
import java.lang.InterruptedException;
import java.io.File;
import java.io.FilenameFilter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;


import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;



 class BytecodeViewer { 

    static final String TITLE = null;   
    static final String FILE = "exe/jvmbytecodes/template.xml";

    static PseudoCodeDisplay pseudo;	
	static ShowFile show;

	static int stackSize=0;
	static int heapSize=0;
	static int currentStackHeight;
	
	static GAIGSarray stack;
	static GAIGSarray localVariableArray;
	static GAIGSstack runTimeStack;
	static GAIGSstack heap;
	static Stack _stack = new Stack();
	static ArrayList _heap;
	static int currentClass;	
    
    public static void main(String args[])  throws IOException {
	BytecodeViewer bcv = new BytecodeViewer();
	bcv.runViewer(args);
   }
	
	
	public void runViewer(String a[]) throws IOException
	{
		show = new ShowFile(a[0],5); //first argument is the script foo.sho
		
    		//generate the bytecodes
    		//String[] temp = {"../../src/exe/reu_bubsort/Test","Factorial4.java"};

		String[] temp = { a[1] , a[2] } ;
		System.out.println( a[0] + " " + a[1] + " " +  a[2] );
		GenerateBytecodes gbc = new GenerateBytecodes();
		gbc.run(temp);
		
		//create visual stack and heap using the predetermined sizes
		stackSize = gbc.classes[0].methods.get(1).stackSize;
		currentStackHeight = gbc.classes[0].methods.get(1).stackSize;
		stack = new GAIGSarray(stackSize, false, "Operand Stack", "#999999", 0.5,0.1,0.9, 0.5, 0.1);
		heap = new GAIGSstack("Heap", "#999999", 0.01,0.5, 0.3, 0.9, 0.15);
		runTimeStack = new GAIGSstack("Run Time Stack", "#999999", 0.01,0.1,0.3, 0.5, 0.15);

		//new xml file		
		currentClass=0;
		generateXMLfile(gbc);	
		
        	try {
		    pseudo = new PseudoCodeDisplay(FILE);
		} 
		catch (JDOMException e) {
		    e.printStackTrace();
		}

		firstMethodCall(gbc);
		//begin interpreter
		Interpreter interp = new Interpreter();
		interp.interpret(gbc.classes[0].methods.get(1).bytecodes, gbc);
		
		runTimeStack.pop();
		show.writeSnap(TITLE, doc_uri(), make_uri(-1, pseudo.RED, gbc), heap, runTimeStack);
		show.close();
	}

	void firstMethodCall(GenerateBytecodes gbc) throws IOException
	{
		//display first method call
		setStackToInitialValues(gbc);
		String mainColor = getRandomColor();
		runTimeStack.push(gbc.classes[0].methods.get(1).name, mainColor);
		localVariableArray = new GAIGSarray(gbc.classes[0].methods.get(1).localVariableTable.length, false, "Local Variables", "#999999", 0.5,0.5,0.9, 0.9, 0.1);
		int j = gbc.classes[0].methods.get(1).localVariableTable.length - 1;		
		for(int i = 0; i < gbc.classes[0].methods.get(1).localVariableTable.length; i++)
		{
			localVariableArray.set("", i);
			localVariableArray.setRowLabel(String.valueOf(j), i);
			j--;
		}
		show.writeSnap(TITLE, doc_uri(), make_uri(-1, pseudo.RED, gbc), heap, runTimeStack);
		show.writeSnap(TITLE, doc_uri(), make_uri(-1, pseudo.RED, gbc), heap, runTimeStack, stack, localVariableArray);
	}

	void setStackToInitialValues(GenerateBytecodes gbc) throws IOException
	{
		for(int i = 0; i < stackSize; i++)
			stack.set("", i);
		show.writeSnap(TITLE, doc_uri(), make_uri(-1, pseudo.RED, gbc), heap, runTimeStack);
	}

	static void generateXMLfile(GenerateBytecodes gbc) throws IOException {
    		
    	String bytecodeStr = ""; 
    	bytecodeStr+="<?xml version=\"1.0\"?>\n";
    	bytecodeStr+="<pseudocode>\n";
    	bytecodeStr+="\t<stack><replace var=\"class_name\" /></stack>\n";
    	bytecodeStr+="\t<code>\n";
    	bytecodeStr+="\t<signature>Java Byte Code</signature>\n";
    	    
    	for (int k=1; k<gbc.classes[currentClass].methods.size(); k++)
    		for (int l=0; l<gbc.classes[currentClass].methods.get(k).bytecodes.length; l++) {
    			bytecodeStr += "\t<line num=\""+ gbc.classes[currentClass].methods.get(k).bytecodes[l].lineNumber+"\">"
				+gbc.classes[currentClass].methods.get(k).bytecodes[l].entireOpcode;
			bytecodeStr +=  "</line>\n";
    		}
    	
    	bytecodeStr+="\t</code>\n";
    	bytecodeStr+="\t<vars>\n";
    	bytecodeStr+="\t<var>heap height = <replace var=\"heap_height\" /></var>\n";
    	bytecodeStr+="\t<var>stack height = <replace var=\"stack_height\" /></var>\n";
    	bytecodeStr+="\t</vars>\n";
    	bytecodeStr+="</pseudocode>\n";
    	
    	String XML = "exe/jvmbytecodes/template.xml";
    	FileOutputStream out = new FileOutputStream(XML);
		out.write(bytecodeStr.getBytes());
		out.flush();
		out.close();
    }
		
     static String make_uri(int line, int color, GenerateBytecodes gbc) {
    	//System.out.println("highlighting line: "+line);
    	return make_uri(new int[]{line}, new int[]{color}, gbc);
    }

    /*
     * Generate the pseudocode for the script file
     */
    	 static String make_uri(int[] lines, int[] colors, GenerateBytecodes gbc) {
    	
    	String sHeight = stackSize == -1 ? "null" : String.valueOf(stackSize-currentStackHeight);
    	String hHeight = heapSize == -1 ? "null" : String.valueOf(heapSize);
    	String current_class_name = gbc.classes[currentClass].name; 

    	//String iVal = i == -1 ? "null" : String.valueOf(i);
    	//String passVal = pass == -1 ? "null" : String.valueOf(pass);
    				               
    	HashMap<String, String> map = new HashMap<String, String>();
    	map.put("stack_height", sHeight);
    	map.put("heap_height", hHeight);
    	map.put("class_name", current_class_name);
    	//map.put("pseu_code", bytecodeStr);
    	//map.put("i", iVal);
    	//map.put("pass", passVal);

    	String uri = null;

		try {
			uri = pseudo.pseudo_uri(map, lines, colors);
		} catch (JDOMException e) {
			e.printStackTrace();
		}

		return uri;
    }

     static String doc_uri() {

        String content = "<html><head><title>JVM</title></head><body><h1>Java Virtual Machine</h1>A visualization with: <br>" + stackSize + "-item stack<br>"+heapSize+"item heap</body></html>";
        URI uri = null;
        try {
            uri = new URI("str", content, "");
        }
        catch (java.net.URISyntaxException e) {
        }
        return uri.toASCIIString();
    }

 	static String getRandomColor() {
 		String returnStr="#";
 		int temp=0;
 		for(int i=0; i<6; i++) {
 			Random rand = new Random();
 			temp = rand.nextInt(7);
 			if (temp == 10)
 				returnStr += "a";
 			else if (temp == 11)
 				returnStr += "b";
 			else if (temp == 12)
 				returnStr += "c";
 			else if (temp == 13)
 				returnStr += "d";
 			else if (temp == 14)
 				returnStr += "e";
 			else if (temp == 15)
 				returnStr += "f";
 			else
 				returnStr += (Integer.toString(temp));
 		}
 		return (returnStr);
 	}



}
 

