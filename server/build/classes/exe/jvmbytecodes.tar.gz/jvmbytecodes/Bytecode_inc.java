package exe.jvmbytecodes;
import java.io.IOException;

/*
 * Recognizes all byte codes that contain inc
 * only iinc implemented
 */
public class Bytecode_inc extends Bytecode_
{

	Bytecode_inc(String str) 
	{
		System.out.println("Enter Bytecode_inc constructor");
		parse(str);
	}

	public int execute(GenerateBytecodes gbc) throws IOException 
	{
		//Inc		next = lineNumber+1;
		//iinc
		if(opcode.contains("ii"))
		{
			System.out.println("Enter iinc");
			int index = getLocalVariableTable(arguments.get(0), gbc);
			System.out.println("Index is: " + index);
			Integer x, y;
			x = Integer.parseInt(arguments.get(1));
			y = Integer.parseInt(gbc.classes[0].methods.get(1).localVariableTable[index][2]);
			int z = x + y;
			System.out.println("z is: " + z);
			gbc.classes[0].methods.get(1).localVariableTable[index][2] = String.valueOf(z);
			localVariableArray.set(z,index);
			show.writeSnap(TITLE, doc_uri(), make_uri(lineNumber, pseudo.RED, gbc), runTimeStack , stack, heap, localVariableArray);	
			System.out.println("hi");
		}


/*
for (int r=0; r < gbc.classes[0].methods.get(1).localVariableTable.length; r++) 
{
    for (int c=0; c < gbc.classes[0].methods.get(1).localVariableTable[r].length; c++) 
	{
		System.out.println(gbc.classes[0].methods.get(1).localVariableTable[r][c]);
	}
}
*/
		next += 2;
		System.out.println(next);
		return next;
	}
}

