class Factorial4
{

 public static void main( String [ ] args )
 {
 int factorial = 1;
 for(int i = 2; i <= 4; i++)
 factorial *= i;
 }
}
