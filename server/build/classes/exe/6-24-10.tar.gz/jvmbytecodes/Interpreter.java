package exe.jvmbytecodes;
import java.io.IOException;

public class Interpreter {
	public Interpreter(){
		
	}

	public void interpret(Bytecode_[] b, GenerateBytecodes gbc) throws IOException
	{
		Bytecode_ bc = b[0];
		bc.execute(gbc);

		while(bc.next != -1)
		{
			for(Bytecode_ x : b)
			{
				if(x.getLineNumber() == bc.next)
				{
					x.execute(gbc);
					bc = x;
				}
				else
					;
			}
		}
	}
}
