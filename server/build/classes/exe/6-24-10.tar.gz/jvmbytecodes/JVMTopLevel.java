/* 
   This file is part of JHAVE -- Java Hosted Algorithm Visualization
   Environment, developed by Tom Naps, David Furcy (both of the
   University of Wisconsin - Oshkosh), Myles McNally (Alma College), and
   numerous other contributors who are listed at the http://jhave.org
   site

   JHAVE is free software: you can redistribute it and/or modify it under
   the terms of the GNU General Public License as published by the Free
   Software Foundation, either version 3 of the License, or (at your
   option) any later version.

   JHAVE is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
   for more details.

   You should have received a copy of the GNU General Public License
   along with the JHAVE. If not, see:
   <http://www.gnu.org/licenses/>.
*/


package exe.jvmbytecodes;

import java.io.*;
import java.util.*;
import java.net.*;

import org.jdom.*;

import exe.*;
import exe.pseudocode.*;

public class JVMTopLevel {

    static final String TITLE = null;   // no title
    static final String FILE = "exe/jvmbytecodes/template.xml";
    static int arraySize;       // # of items to sort
    static GAIGSarray items;    // the array of items
    static PseudoCodeDisplay pseudo;	// The pseudocode
	 static boolean success;
    public static void main(String args[]) throws IOException {
   
    // process program parameters and create the show file object
	//ShowFile show = new ShowFile(args[0] + ".sho");
    //arraySize = Integer.parseInt(args[1]);
	
	System.out.println("JVMTopLevel.java args[0]: "+args[0]+" args[1]: "+args[1]+" args[2]: "+args[2]);
		  
	String file_contents = args[2];	


	// args[0] is the full path and number for naming showfile
	// args[1] is the name of the Java source file or ""
	// args[2] is the contents of the Java file

	File pathname = new File("",args[0]);
	String fileName = (args[1].equals("") ? "Test.java" : args[1] );
			
	try{
	    success = (pathname.mkdir());
	}catch (Exception e){
	    System.err.println("Error: " + e.getMessage()); 
	} 
	try{
	    FileWriter fw = new FileWriter ( args[0]+ "/" + fileName);
	    BufferedWriter bw = new BufferedWriter (fw);
	    PrintWriter outFile = new PrintWriter (bw);
	    outFile.print( file_contents );
	    outFile.close();
	}catch (Exception e){
	    System.err.println("Error: " + e.getMessage()); 
	} 
        try {
	    pseudo = new PseudoCodeDisplay(FILE);
	} catch (JDOMException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	
	String[] tmp = { args[0] + ".sho" , args[0], args[1] };
	//System.out.println( tmp[0] + " " + tmp[1]);
	
	new BytecodeViewer().runViewer( tmp );

	/*
        GAIGStext message = new GAIGStext(0.5,0.5,success + " " + args[0] + " " + pathname.getName() + " '" + args[2] + "'"); 
        show.writeSnap(TITLE, doc_uri(arraySize), make_uri(-1, -1, 0, PseudoCodeDisplay.RED), message);
	*/

        // visualization is done
        //show.close();  
    }
    /*
    private static String make_uri(int pass, int i, int line, int color) {
    	return make_uri(pass, i, new int[]{line}, new int[]{color});
    }

    private static String make_uri(int pass, int i, int[] lines, int[] colors) {
    	String passVal = pass == -1 ? "null" : String.valueOf(pass);
    	String iVal = i == -1 ? "null" : String.valueOf(i);
    	String stack = "main program\n" + 
	               "  bubbleSort(items)";

    	HashMap<String, String> map = new HashMap<String, String>();
    	map.put("pass", passVal);
    	map.put("i", iVal);
    	map.put("s", stack);

    	String uri = null;
    	try {
	    uri = pseudo.pseudo_uri(map, lines, colors);
	} catch (JDOMException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

	return uri;
    }

    // Load the array with values from 1 to the array size, then
    // shuffle these values so that they appear in random order.
    private static void loadArray () {
        Random rand = new Random();
        for (int i = 0; i < arraySize; i++)
            items.set(i+1,i);
        for (int i = 0; i < arraySize-1; i++)
            swap(i, i + (Math.abs(rand.nextInt()) 
                         % (arraySize - i)) );
    }
    

    // Swap two items in the array.
    private static void swap (int loc1, int loc2) {
        Object temp = items.get(loc1);
        items.set(items.get(loc2), loc1);
        items.set(temp, loc2);    
    }

    // Return an appropriate inline string for the info page 
    private static String doc_uri(int num_items) {
	//        String content = "<html><head><title>Bubble Sort</title></head><body><h1>Bubble Sort</h1>The famous bubble sort on a " + num_items + "-item array</body></html>";
        String content = "<html><head><title>Bubble Sort</title></head><body><h1>Bubble Sort</h1>The famous bubble sort on a " + num_items + "-item array</body></html>";
        URI uri = null;
        try {
            uri = new URI("str", content, "");
        }
        catch (java.net.URISyntaxException e) {
        }
        return uri.toASCIIString();
    }
    */
}
