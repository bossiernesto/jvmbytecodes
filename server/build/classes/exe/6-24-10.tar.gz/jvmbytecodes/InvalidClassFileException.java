package exe.jvmbytecodes;
import java.io.IOException;
import java.lang.InterruptedException;
import java.io.File;
import java.io.FilenameFilter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;



class InvalidClassFileException extends RuntimeException {

    String errorMessage;

    InvalidClassFileException(String errorMessage) {
	this.errorMessage = errorMessage;
    }

    public String toString() {
	return errorMessage;
    }
}
